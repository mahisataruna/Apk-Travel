    <!-- Registration Page -->
    <!-- ============================================================== -->

        <!-- Preloader - style you can find in spinners.css -->
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
    
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->
        <!-- ============================================================== -->
        <!-- ============================================================== -->
    
        <!-- Login box.scss -->
        <!-- ============================================================== -->
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative">
            
            <div class="auth-box row col-lg-7 mx-auto">
                
                <div class="col-lg col-md bg-white mx-auto">
                    <div class="p-3">

                        <div class="text-center">
                            <img src="<?= base_url('assets'); ?>/images/big/icon.png" alt="wrapkit">
                        </div>
                        <!-- Judul Halaman -->
                        <h1 class="mt-3 text-center">Trans Traffic Registration</h1>

                        <div class="card-body mb-4">
                            <form action="<?= base_url('auth/registration'); ?>" method="post">
                            <div class="row">
                                <div class="col-lg-7 mx-auto">
                                    <?= form_error('name','<small class="text-danger pl">','</small>'); ?>
                                    <div class="form-group">
                                        <input class="form-control" type="text" id="name" name="name" placeholder="Nama Lengkap" value="<?= set_value('name'); ?>">
                                    </div>
                                </div>

                                <div class="col-lg-7 mx-auto">
                                    <?= form_error('email','<small class="text-danger pl">','</small>'); ?>
                                    <div class="form-group">
                                        <input class="form-control" type="email" id="email" name="email" placeholder="Alamat Email" value="<?= set_value('email'); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-7 mx-auto">
                                    <?= form_error('password1','<small class="text-danger pl">','</small>'); ?>
                                    <div class="form-group">
                                        <input class="form-control" type="password" id="password1" name="password1" placeholder="password">
                                    </div>
                                </div>
                                <div class="col-lg-7 mx-auto">
                                    <div class="form-group">
                                        <input class="form-control" type="password" id="password2" name="password2" placeholder="Ulangi password">
                                    </div>
                                </div>
                                <div class="col-lg-7 text-center mx-auto">
                                    <button type="submit" class="btn btn-block btn-success">Daftar</button>
                                </div>
                                <div class="col-lg-12 text-center mt-3">
                                    <p class="mb-0">
                                    Sudah memiliki akun? 
                                    <a href="<?= base_url('auth'); ?>" class="text-danger">Masuk</a>
                                    </p>
                                </div>
                            </div>
                            </form>
                        </div>
                    
                    </div>
                </div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
    