
        <!-- Mulai Login Page Disini -->
        <!-- ============================================================== -->

        <!-- Preloader - style you can find in spinners.css -->
        <div class="preloader">
            <div class="lds-ripple">
                <div class="lds-pos"></div>
                <div class="lds-pos"></div>
            </div>
        </div>
        <!-- ============================================================== -->
        <!-- Preloader - style you can find in spinners.css -->

        <!-- Login box.scss -->
        <!-- ============================================================== -->
        
        <div class="auth-wrapper d-flex no-block justify-content-center align-items-center position-relative">

            <div class="auth-box row col-lg-7 mx-auto">     
                <div class="col-lg col-md bg-gradient-light mx-auto">
                    <div class="p-3">
                                <!-- Disini Letakkan Logo -->
                        <div class="text-center">
                            <img src="<?= base_url('assets'); ?>/images/big/icon.png" alt="wrapkit">
                        </div>
                        <!-- Judul Halaman -->
                        <h1 class="mt-3 text-center">Trans Traffic</h1>

                            <div class="card-body mb-4">
                                    <?= $this->session->flashdata('message'); ?>
                                    <form action="#" method="post">
                                    <div class="row">
                                        <div class="col-lg-7 mx-auto">
                                            <div class="form-group">
                                                <label class="text-dark" for="uname">Email</label>
                                                <input class="form-control" id="name" name="name" type="text"
                                                placeholder="Masukkan Email">
                                            </div>
                                        </div>
                                        <div class="col-lg-7 mx-auto">
                                            <div class="form-group">
                                                <label class="text-dark" for="pwd">Password</label>
                                                <input class="form-control" id="email" name="email" type="password"
                                                placeholder="Masukkan password">
                                            </div>
                                        </div>
                                        <div class="col-lg-7 mx-auto text-center">
                                            <!-- Tambahkan Button -->
                                            <button type="submit" class="btn btn-block btn-success">Masuk</button>
                                    
                                            <div class="col-lg-7 mx-auto text-center mt-3">
                                                <a href="#" class="text-primary">Lupa password</a>
                                            </div>
                                        </div>
                                
                                        <div class="col-lg-6 mx-auto text-center mt-2">
                                            <p class="mb-0"> Belum punya akun? 
                                                <a href="<?= base_url('auth/registration');?>" class="text-danger">Daftar disini
                                                </a>
                                            </p>
                                        </div>
                                    </div>
                                    </form>
                            </div>
                    </div>
                </div>
            </div>
            
        </div>

        <!-- ============================================================== -->
        <!-- Login box.scss -->
        <!-- ============================================================== -->
    